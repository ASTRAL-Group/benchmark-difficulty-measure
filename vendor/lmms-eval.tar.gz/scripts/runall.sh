#!/bin/bash
set -u

failed=0
#,mmlu_pro_chemistry,mmlu_pro_physics,gpqa_diamond_cot_n_shot,scienceqa,ifeval,zebralogic_grid,bbh_cot_zeroshot_logic,medqa
# export TASKS="mmlu_pro_chemistry,mmlu_pro_physics"

# for round in 31 32 33 34; do
#   echo "[INFO] Round $round"
#   export EVAL_SEED=$round
#   # bash scripts/qwen397b.sh || { echo "[WARN] QwQ-32B failed"; failed=1; }
#   bash scripts/GLM-4.5-Air.sh || { echo "[WARN] GLM-4.5-Air failed"; failed=1; }
#   # bash scripts/GLM-4.6.sh || { echo "[WARN] GLM-4.6 failed"; failed=1; }
#   # bash scripts/Olmo-3.1-32B-Think.sh || { echo "[WARN] Olmo-3.1-32B-Think failed"; failed=1; }
#   # bash scripts/qwen3-80b-a3b.sh || { echo "[WARN] qwen3-80b-a3b failed"; failed=1; }
# done

export TASKS="gpqa_diamond_cot_n_shot,mmlu_pro_chemistry,mmlu_pro_physics,zebralogic_grid"
for round in 51 52 53 54; do
  echo "[INFO] Round $round"
  export EVAL_SEED=$round
  # bash scripts/qwen397b.sh || { echo "[WARN] QwQ-32B failed"; failed=1; }
  # bash scripts/GLM-4.5-Air.sh || { echo "[WARN] GLM-4.5-Air failed"; failed=1; }
  # bash scripts/GLM-4.6.sh || { echo "[WARN] GLM-4.6 failed"; failed=1; }
  # bash scripts/Olmo-3.1-32B-Think.sh || { echo "[WARN] Olmo-3.1-32B-Think failed"; failed=1; }
  bash scripts/qwen3-80b-a3b.sh || { echo "[WARN] qwen3-80b-a3b failed"; failed=1; }
done

# export TASKS="zebralogic_grid"
# for round in 39; do
#   echo "[INFO] Round $round"
#   export EVAL_SEED=$round
#   # bash scripts/qwen397b.sh || { echo "[WARN] QwQ-32B failed"; failed=1; }
#   bash scripts/GLM-4.5-Air.sh || { echo "[WARN] GLM-4.5-Air failed"; failed=1; }
#   # bash scripts/GLM-4.6.sh || { echo "[WARN] GLM-4.6 failed"; failed=1; }
#   # bash scripts/Olmo-3.1-32B-Think.sh || { echo "[WARN] Olmo-3.1-32B-Think failed"; failed=1; }
#   # bash scripts/qwen3-80b-a3b.sh || { echo "[WARN] qwen3-80b-a3b failed"; failed=1; }
# done



# for round in 1 2 3 4; do
#   echo "[INFO] Round $round"
#   export EVAL_SEED=$round
#   # bash scripts/GLM-4.5-Air.sh || { echo "[WARN] GLM-4.5-Air failed"; failed=1; }
#   # bash scripts/GLM-4.6.sh || { echo "[WARN] GLM-4.6 failed"; failed=1; }
#   bash scripts/gpt-oss-20b.sh || { echo "[WARN] gpt-oss-20b failed"; failed=1; }
# done
exit $failed
