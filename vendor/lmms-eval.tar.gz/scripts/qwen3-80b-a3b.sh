#!/bin/bash

set -euo pipefail

export HF_HOME="${HF_HOME:-$HOME/.cache/huggingface}"
export HF_TOKEN="${HF_TOKEN:-$(cat "$HF_HOME/token")}"
export HUGGINGFACE_HUB_TOKEN="${HUGGINGFACE_HUB_TOKEN:-$HF_TOKEN}"

export NCCL_BLOCKING_WAIT="${NCCL_BLOCKING_WAIT:-1}"
export NCCL_TIMEOUT="${NCCL_TIMEOUT:-18000000}"

MODEL="${MODEL:-Qwen/Qwen3-Next-80B-A3B-Instruct}"
TASKS="${TASKS:-gpqa_diamond_cot_n_shot,scienceqa,ifeval,zebralogic_grid,bbh_cot_zeroshot_logic,medqa}"
BATCH_SIZE="${BATCH_SIZE:-114514}"
OUTPUT_PATH="${OUTPUT_PATH:-./logs}"
VERBOSITY="${VERBOSITY:-DEBUG}"
TENSOR_PARALLEL_SIZE="${TENSOR_PARALLEL_SIZE:-8}"
GPU_MEMORY_UTILIZATION="${GPU_MEMORY_UTILIZATION:-0.90}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-65536}"

echo "[INFO] vLLM test (Qwen3-80B-A3B-Instruct)"
echo "[INFO] model=${MODEL} tasks=${TASKS} batch_size=${BATCH_SIZE} tp=${TENSOR_PARALLEL_SIZE}"
echo "[INFO] output_path=${OUTPUT_PATH}"

uv run python -m lmms_eval \
  --model vllm \
  --model_args "model=${MODEL},tensor_parallel_size=${TENSOR_PARALLEL_SIZE},gpu_memory_utilization=${GPU_MEMORY_UTILIZATION},max_model_len=${MAX_MODEL_LEN},max_num_seqs=512,seed=${EVAL_SEED:-0}" \
  --tasks "${TASKS}" \
  --batch_size "${BATCH_SIZE}" \
  --output_path "${OUTPUT_PATH}" \
  --log_samples \
  --gen_kwargs "temperature=0.6,top_k=20,top_p=0.95,do_sample=True,max_new_tokens=32768" \
  --seed "${EVAL_SEED:-0}" \
  --run_id "run${EVAL_SEED:-0}" \
  --verbosity "${VERBOSITY}"
