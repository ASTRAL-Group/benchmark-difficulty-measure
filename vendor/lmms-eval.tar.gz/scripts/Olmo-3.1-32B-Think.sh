#!/bin/bash

set -euo pipefail

export HF_HOME="${HF_HOME:-$HOME/.cache/huggingface}"
export HF_TOKEN="${HF_TOKEN:-$(cat "$HF_HOME/token")}"
export HUGGINGFACE_HUB_TOKEN="${HUGGINGFACE_HUB_TOKEN:-$HF_TOKEN}"

export NCCL_BLOCKING_WAIT="${NCCL_BLOCKING_WAIT:-1}"
export NCCL_TIMEOUT="${NCCL_TIMEOUT:-18000000}"

MODEL="${MODEL:-allenai/Olmo-3.1-32B-Think}"
TASKS="${TASKS:-zebralogic_grid}"
BATCH_SIZE="${BATCH_SIZE:-114514}"
OUTPUT_PATH="${OUTPUT_PATH:-./logs}"
VERBOSITY="${VERBOSITY:-DEBUG}"
TENSOR_PARALLEL_SIZE="${TENSOR_PARALLEL_SIZE:-4}"
GPU_MEMORY_UTILIZATION="${GPU_MEMORY_UTILIZATION:-0.85}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-20480}"

echo "[INFO] vLLM test (Olmo-3.1-32B-Think)"
echo "[INFO] model=${MODEL} tasks=${TASKS} batch_size=${BATCH_SIZE} tp=${TENSOR_PARALLEL_SIZE}"
echo "[INFO] output_path=${OUTPUT_PATH}"

uv run python -m lmms_eval \
  --model vllm \
  --model_args "model=${MODEL},tensor_parallel_size=${TENSOR_PARALLEL_SIZE},gpu_memory_utilization=${GPU_MEMORY_UTILIZATION},max_model_len=${MAX_MODEL_LEN},max_num_seqs=128,seed=${EVAL_SEED:-0}" \
  --tasks "${TASKS}" \
  --batch_size "${BATCH_SIZE}" \
  --output_path "${OUTPUT_PATH}" \
  --log_samples \
  --gen_kwargs "temperature=0.6,top_k=20,top_p=0.95,do_sample=True,max_new_tokens=10240" \
  --seed "${EVAL_SEED:-0}" \
  --run_id "run${EVAL_SEED:-0}" \
  --verbosity "${VERBOSITY}"