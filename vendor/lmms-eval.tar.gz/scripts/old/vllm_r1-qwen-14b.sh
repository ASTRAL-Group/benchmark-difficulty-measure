#!/bin/bash

set -euo pipefail

export HF_HOME="${HF_HOME:-$HOME/.cache/huggingface}"
export NCCL_BLOCKING_WAIT="${NCCL_BLOCKING_WAIT:-1}"
export NCCL_TIMEOUT="${NCCL_TIMEOUT:-18000000}"


#mmlu_pro,gpqa_diamond_cot_n_shot,super_gpqa,scienceqa,ifeval
MODEL="${MODEL:-deepseek-ai/DeepSeek-R1-Distill-Qwen-14B}"
TASKS="${TASKS:-bbh_cot_zeroshot}"
BATCH_SIZE="${BATCH_SIZE:-114514}"
OUTPUT_PATH="${OUTPUT_PATH:-./logs/deepseek-r1-distill-qwen-14b}"
VERBOSITY="${VERBOSITY:-DEBUG}"
TENSOR_PARALLEL_SIZE="${TENSOR_PARALLEL_SIZE:-4}"
GPU_MEMORY_UTILIZATION="${GPU_MEMORY_UTILIZATION:-0.88}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-32768}"

echo "[INFO] vLLM test (Qwen3-14b)"
echo "[INFO] model=${MODEL} tasks=${TASKS} batch_size=${BATCH_SIZE} tp=${TENSOR_PARALLEL_SIZE}"
echo "[INFO] output_path=${OUTPUT_PATH}"

uv run python -m lmms_eval \
  --model vllm \
  --model_args "model=${MODEL},tensor_parallel_size=${TENSOR_PARALLEL_SIZE},gpu_memory_utilization=${GPU_MEMORY_UTILIZATION},max_model_len=${MAX_MODEL_LEN},max_num_seqs=512" \
  --tasks "${TASKS}" \
  --batch_size "${BATCH_SIZE}" \
  --output_path "${OUTPUT_PATH}" \
  --log_samples \
  --verbosity "${VERBOSITY}"\
  # --force_simple\


