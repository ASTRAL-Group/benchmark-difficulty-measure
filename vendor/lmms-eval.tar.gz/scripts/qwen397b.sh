set -euo pipefail

export HF_HOME="${HF_HOME:-$HOME/.cache/huggingface}"
export NCCL_BLOCKING_WAIT="${NCCL_BLOCKING_WAIT:-1}"
export NCCL_TIMEOUT="${NCCL_TIMEOUT:-18000000}"

#mmlu_pro_science,scienceqa,ifeval,zebralogic_grid,bbh_cot_zeroshot_logic,medqa
MODEL="${MODEL:-Qwen/Qwen3.5-397B-A17B-FP8}"
TASKS="${TASKS:-scienceqa,ifeval,zebralogic_grid,bbh_cot_zeroshot_logic,medqa}"
BATCH_SIZE="${BATCH_SIZE:-114514}"
OUTPUT_PATH="${OUTPUT_PATH:-./logs}"
VERBOSITY="${VERBOSITY:-DEBUG}"
TENSOR_PARALLEL_SIZE="${TENSOR_PARALLEL_SIZE:-8}"
GPU_MEMORY_UTILIZATION="${GPU_MEMORY_UTILIZATION:-0.85}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-65536}"

echo "[INFO] vLLM test Qwen3.5-397B-A17B-FP8"
echo "[INFO] model=${MODEL} tasks=${TASKS} batch_size=${BATCH_SIZE} tp=${TENSOR_PARALLEL_SIZE}"
echo "[INFO] output_path=${OUTPUT_PATH}"

export EVAL_SEED="${EVAL_SEED:-0}"

uv run python -m lmms_eval \
  --model vllm \
  --model_args "model=${MODEL},tensor_parallel_size=${TENSOR_PARALLEL_SIZE},gpu_memory_utilization=${GPU_MEMORY_UTILIZATION},max_model_len=${MAX_MODEL_LEN},max_num_seqs=512,seed=${EVAL_SEED}" \
  --tasks "${TASKS}" \
  --batch_size "${BATCH_SIZE}" \
  --output_path "${OUTPUT_PATH}" \
  --log_samples \
  --system_instruction "You are a helpful assistant." \
  --gen_kwargs "temperature=0.6,top_k=20,top_p=0.95,do_sample=True,max_new_tokens=32768" \
  --seed "${EVAL_SEED}" \
  --run_id "run${EVAL_SEED}" \
  --verbosity "${VERBOSITY}"