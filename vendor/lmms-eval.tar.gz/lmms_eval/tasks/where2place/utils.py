import re
from typing import Any, Dict, List

import numpy as np

from lmms_eval.tasks._task_utils.default_template_yaml import load_default_template_yaml

PROMPT_SUFFIX_0_999 = "Your answer should be formatted as a list of tuples, i.e. [(x1, y1), (x2, y2), ...], where each tuple contains the x and y coordinates of a point satisfying the conditions above. The coordinates should be integers between 0 and 999, representing the pixel locations scaled to a 1000×1000 grid."
PROMPT_SUFFIX_ORIGINAL = "Your answer should be formatted as a list of tuples, i.e. [(x1, y1), (x2, y2), ...], where each tuple contains the x and y coordinates of a point satisfying the conditions above. The coordinates should be between 0 and 1, indicating the normalized pixel locations of the points in the image."
FORMAT = "Return only list of tuples, don't add anything else."


config = load_default_template_yaml(__file__)


def where2place_doc_to_text(doc: dict[str, Any]) -> str:
    if config.get("metadata", {}).get("prompt_suffix_type", {}) == "0_999":
        return f"{doc['question']} {PROMPT_SUFFIX_0_999} {FORMAT}"
    return f"{doc['question']} {PROMPT_SUFFIX_ORIGINAL} {FORMAT}"


def where2place_doc_to_visual(doc: dict) -> list:
    return [doc["image"].convert("RGB")]


#  inspired by original repo: https://github.com/wentaoyuan/RoboPoint/blob/master/robopoint/eval/summarize_vqa.py
def _text2pts(text: str, width: int = 640, height: int = 480, normalization_constant: int = 1, is_absolute: bool = False) -> np.ndarray:
    pattern = r"\(([-+]?\d+\.?\d*(?:,\s*[-+]?\d+\.?\d*)*?)\)"
    matches = re.findall(pattern, text)
    points = []

    for match in matches:
        vector = [float(num) if "." in num else int(num) for num in match.split(",")]
        if len(vector) == 2:
            x, y = vector
            if not is_absolute:
                x = int(x / normalization_constant * width)
                y = int(y / normalization_constant * height)
            points.append((x, y))

    return np.array(points)


# inspired by original work: https://github.com/wentaoyuan/RoboPoint/blob/master/robopoint/eval/summarize_vqa.py
def where2place_process_results(doc: Dict, result: List[str]) -> Dict[str, Dict]:
    key_name = "where2place_acc"

    mask = np.array(doc["mask"]) / 255.0
    # some values might not be exactly 255 or 0
    mask = np.round(mask, 0).astype(int)
    if mask.ndim == 3:
        mask = mask[:, :, 0]

    # extract grounded answer
    response = result[0]

    try:
        prompt_suffix_type = config.get("metadata", {}).get("prompt_suffix_type", {})
    except Exception:
        prompt_suffix_type = {}
    normalization_constant = 1000 if prompt_suffix_type == "0_999" else 1
    points = _text2pts(response, mask.shape[1], mask.shape[0], normalization_constant)

    # process the answer
    acc = 0.0
    if len(points) > 0:
        in_range = (points[:, 0] >= 0) & (points[:, 0] < mask.shape[1]) & (points[:, 1] >= 0) & (points[:, 1] < mask.shape[0])
        acc = np.concatenate([mask[points[in_range, 1], points[in_range, 0]], np.zeros(points.shape[0] - in_range.sum())]).mean()
    where2place_submission = {"id": doc["question_id"], "pred": response, "parsed_points": list(map(tuple, points)), "accuracy": acc}
    return {key_name: where2place_submission}


def where2place_aggregate_results(results: List[Dict]) -> float:
    return float(np.mean([sample["accuracy"] for sample in results]))
